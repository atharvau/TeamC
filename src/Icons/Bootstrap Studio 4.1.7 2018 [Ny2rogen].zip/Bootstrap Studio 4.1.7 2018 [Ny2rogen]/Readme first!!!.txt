- This software requires internet connection and will NOT work without an internet connection.
- DO NOT update this software!
- This is an auto-installer (silent installer) which does not require any user action, just run the "Setup.exe" file as administrator and it will install Bootstrap Studio 4.1.7 to your Program Files (x86) and automatically creates a shortcut on the Desktop and after completing the installation Bootstrp Studio will launch automatically.

That's it! :)
Find me at: www.thepiratebay.org/user/Ny2rogen